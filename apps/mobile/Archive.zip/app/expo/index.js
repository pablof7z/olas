import 'react-native-get-random-values';
import 'expo-router/entry';
