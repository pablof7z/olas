import React from 'react';
import LoginScreen from '@/lib/onboard/screens/LoginScreen';

export default function Login() {
    return <LoginScreen />;
}
