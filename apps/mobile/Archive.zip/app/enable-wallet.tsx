import WalletScreen from "./(home)/(settings)/wallets";

export default WalletScreen;