import { StickerModal } from "@/lib/new-story-editor/StickerModal";

export default function Modal() {
    return <StickerModal />
}