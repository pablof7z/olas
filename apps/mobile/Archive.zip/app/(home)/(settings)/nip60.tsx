import { Text } from '@/components/nativewindui/Text';

export default function Nip60() {
    return <Text>NIP-60</Text>;
}
