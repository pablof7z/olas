import { StyleSheet, Dimensions, View, ScrollView, Platform, TouchableOpacity } from 'react-native';
import { useHeaderHeight } from '@react-navigation/elements';
import { Text } from '@/components/nativewindui/Text';
import { NDKKind, NDKUserProfile, useSubscribe, useUserProfile } from '@nostr-dev-kit/ndk-mobile';
import { NDKEvent } from '@nostr-dev-kit/ndk-mobile';
import * as User from '@/components/ui/user';
import RelativeTime from '@/components/relative-time';
import EventContent from '@/components/ui/event/content';
import EventMediaContainer from '@/components/media/event';
import { Reactions } from '@/components/events/Post/Reactions';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useCallback, useMemo } from 'react';
import { useAtomValue } from 'jotai';
import { activeEventAtom } from '@/stores/event';
import { router, Stack } from 'expo-router';
import { nicelyFormattedSatNumber } from '@/utils/bitcoin';
import { useUserFlare } from '@/hooks/user-flare';
import BackButton from '@/components/buttons/back-button';
import { useReactionsStore } from '@/stores/reactions';
import AvatarAndName from '@/components/ui/user/avatar-name';

function getUrlFromEvent(event: NDKEvent) {
    let url = event.tagValue('thumb') || event.tagValue('url') || event.tagValue('u');

    // if this is a kind:1 see if there is a URL in the content that ends with .jpg, .jpeg, .png, .gif, .webp
    if (!url && event.kind === NDKKind.Text) {
        const content = event.content;
        const urlMatch = content.match(/https?:\/\/[^\s/$.?#].[^\s]*\.(jpg|jpeg|png|webp)/i);
        if (urlMatch) {
            url = urlMatch[0];
        }
    }

    return url;
}

function Header({ event }: { event: NDKEvent }) {
    const { userProfile } = useUserProfile(event.pubkey);
    const insets = useSafeAreaInsets();
    const flare = useUserFlare(event.pubkey);

    const viewProfile = useCallback(() => {
        router.push(`/profile?pubkey=${event.pubkey}`);
    }, [event.pubkey])
    
    return (
        <View style={[headerStyles.container, { paddingTop: insets.top }]}>
            <BackButton />

            <AvatarAndName pubkey={event.pubkey} userProfile={userProfile} onPress={viewProfile} imageSize={24} borderColor='black' canSkipBorder={true} pressableStyle={{ padding: 16 }} />

            <Text style={headerStyles.timestamp}>
                <RelativeTime timestamp={event.created_at!} />
            </Text>
        </View>
    )
}

const headerStyles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    timestamp: {
        fontSize: 12,
        color: '#9CA3AF', // Tailwind 'text-gray-400'
    },
})

export default function ViewScreen() {
    const activeEvent = useAtomValue<NDKEvent>(activeEventAtom);
    const reactions = useReactionsStore(state => state.reactions.get(activeEvent?.tagId() ?? ''));
    const {events} = useSubscribe( activeEvent ? [
        activeEvent.filter(),
    ] : false, { groupable: false }, [activeEvent?.id]);

    const height = useHeaderHeight(); 
    const insets = useSafeAreaInsets();
    const style = useMemo(() => ({
            paddingTop: height,
    }), [height]);

    if (!activeEvent) {
        return <Text style={styles.noActiveEvent}>No active event</Text>;
    }

    const url = getUrlFromEvent(activeEvent);
    let content = activeEvent.content;
    let title = null;
    let price = null;
    let currency = null;

    if (activeEvent.kind === 30018) {
        const parsed = JSON.parse(activeEvent.content);
        title = parsed.name;
        content = parsed.description;
        price = parsed.price;
        currency = parsed.currency;
    }

    // remove url from content
    if (url) {
        content = content.replace(url, '');
    }

    return (
        <>
            <Stack.Screen
                options={{
                    headerShown: true,
                    headerTransparent: true,
                    headerTintColor: "white",
                    header: () => <Header event={activeEvent} />
                }}
            />
            <View style={[styles.scrollView, style]}>
                <ScrollView minimumZoomScale={1} maximumZoomScale={5} style={{ flex: 1 }}
                contentContainerStyle={{ flex: 1 }}>
                    <EventMediaContainer
                        event={activeEvent}
                        contentFit="contain"
                        maxWidth={Dimensions.get('window').width}
                        maxHeight={Dimensions.get('window').height}
                        muted={false}
                        autoplay={true}
                    />
                </ScrollView>

                {/* Content */}
                <View style={[styles.contentContainer, { paddingBottom: insets.bottom * 2 }]}>
                    {price && <Text numberOfLines={1} variant="title1" className="text-white">{nicelyFormattedSatNumber(price)} {currency.toLowerCase()}</Text>}
                    {title && <Text numberOfLines={1} variant="title1" className="text-white">{title}</Text>}
                    <EventContent event={activeEvent} content={content} style={styles.eventContent} />
                    <Reactions event={activeEvent} foregroundColor='white' inactiveColor='white' reactions={reactions} />
                </View>
            </View>
        </>
    );
}

const styles = StyleSheet.create({
    scrollView: {
        flex: 1,
        backgroundColor: '#000',
    },
    container: {
        flex: 1,
    },
    userInfo: {
        marginLeft: 12,
    },
    userName: {
        fontWeight: 'bold',
        color: '#FFFFFF',
    },
    timestamp: {
        fontSize: 12,
        color: '#9CA3AF', // Tailwind 'text-gray-400'
    },
    contentContainer: {
        padding: 16,
        flexDirection: 'column',
        gap: 16,
    },
    eventContent: {
        fontSize: 12,
        color: '#FFFFFF',
    },
    noActiveEvent: {
        color: '#FFFFFF',
        fontSize: 16,
        textAlign: 'center',
        marginTop: 20,
    },
});
