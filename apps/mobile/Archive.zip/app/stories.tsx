import StoriesModal from "@/lib/stories/Modal";

export default function Stories() {
    return (
        <StoriesModal />
    )
}