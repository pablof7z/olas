import { atom } from "jotai";

export const relayNoticesAtom = atom<Record<string, string[]>>({});
