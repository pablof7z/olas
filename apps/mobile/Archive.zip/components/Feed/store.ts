import { atom } from "jotai";

export const scrollDirAtom = atom<"up" | "down">("up");